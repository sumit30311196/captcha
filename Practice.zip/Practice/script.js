// declare all characters ///Captcha
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
var length = 5;
var result = '';
const charactersLength = characters.length;
for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
}
let captcha1 = document.getElementById("captcha1");
captcha1.innerHTML = result;
actual_captcha = result;
captcha1.style.userSelect = 'none';          // Standard syntax
captcha1.style.msUserSelect = 'none';        // IE 10+

//  Captcha-Refresh //
var refresh = document.getElementById("refresh");
refresh.onclick = function () {
    result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    document.getElementById('captcha1').innerHTML = result;
    actual_captcha = result;
}


//captcha login
function captcha(){
    let cpt = document.getElementById("cpt");
    if(cpt.value.length === 0){
        alert("Enter Captcha");
    }
    else if(cpt.value !== result){
        alert("Enter Write Captcha");
    }else{
        cpt.value = "";
        //alert("ok");
        window.location.href = "otp_login";
    }
}