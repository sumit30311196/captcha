

// Get the query string from the current URL
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const user = urlParams.get('user');
console.log(user); // Should output: sumit58@gmail.com

//get id
let userid = document.getElementById("userid");
if(!user == null){
  userid.value = user;
}
//userid.value = user;

// Retrieve the 'sts' parameter
const sts = urlParams.get('sts');

if (sts == "Sucess") {
  Swal.fire({
    title: "Data Added Successfully",
    icon: "success",
    draggable: true
  });
}
if (sts == "Delete") {
  Swal.fire({
    title: "Data Deleted Successfully",
    icon: "success",
    draggable: true
  });
}



//loginvalidation()--------------------------------------------------------//
function loginvalidation() {
  let l_email = document.getElementById("l_email").value;
  let l_password = document.getElementById("l_password").value;

  if (l_email == "") {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "User Name Must Be Filled Out"
    });
    return false;
  }
  else if (!l_email.match(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/)) {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Please Enter a Valid Email Address"
    });
    return false;
  }
  else if (l_password == "") {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Password Must Be Filled Out"
    });
    return false;
  }
}

//regvalidate()--------------------------------------------------------//
function regvalidate(){
  let r_name = document.getElementById("r_name").value;
  let r_email = document.getElementById("r_email").value;
  let r_user = document.getElementById("r_user").value;
  let r_phone = document.getElementById("r_phone").value;
  let r_pass = document.getElementById("r_pass").value;

    if (r_name == "") {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Name Must Be Filled Out"
      });
      return false;
    }
    else if(r_email == ""){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Email Must Be Filled Out"
      });
      return false;
    }
    else if (!r_email.match(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/)) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please Enter a Valid Email Address"
      });
      return false;
    }
    else if(r_user == ""){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Username Must Be Filled Out"
      });
      return false;
    }
    else if(r_phone == ""){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Phone No Must Be Filled Out"
      });
      return false;
    }
    else if(isNaN(r_phone)){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please Enter Only Number"
      });
      return false;
    }
    else if(!r_phone.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please Enter Validate Mobile Number"
      });
      return false;
    }
    else if(r_pass == ""){
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Password Must Be Filled Out"
      });
      return false;
    }
}