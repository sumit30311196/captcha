<?php
include 'db.php';

session_start();
// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  // Redirect to the login page
  header('Location: login.php');
  exit;
}

$id = $_GET['id'];
$sql = "DELETE FROM `add_crud` WHERE id = $id";
$result = $conn->query($sql);
$sqll = "ALTER TABLE `add_crud` AUTO_INCREMENT = $id";
$resultt = $conn->query($sqll);
if ($resultt) {

}

if ($result) {
  if (isset($_SESSION['user_id'])){
    $user_id = $_SESSION['user_id'];
    header("Location: index1.php?user=$user_id&sts=Delete");
  }
}
