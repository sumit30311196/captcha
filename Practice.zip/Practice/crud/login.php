<?php 
    include 'header.php';
    include 'db.php';

    session_start();

    // Check if the user is already logged in, if yes, redirect them to main.php
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
        header('Location: index1.php');
        exit;
    }

    if(isset($_POST['submit'])){
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM `form` WHERE `email`='$user' AND `password`='$pass'";
    $result = mysqli_query($conn, $sql);
    $res = mysqli_num_rows($result);

    if($res > 0){
        $_SESSION['logged_in'] = true;
        $_SESSION['user_id'] = $user;
        header("location: index1.php?user=$user");
        exit();
    }else{
        header("location: login.php");
        $_SESSION['message']="Incorrect Username or Password."; 
        exit();
    }
}

if(isset($_SESSION['message'])){
    $error = $_SESSION['message'];
    unset($_SESSION['message']);
}

$conn->close();

?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="bg">
    <div class="login-reg">     
        <div class="log" id="sign">
            <h2 class="text-center">User Login</h2>
            <span></span><br>
            <form onsubmit="return loginvalidation()" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="log_in">
                <label for="">Username:</label><br>
                <input type="text" name="user" id="l_email" placeholder="Enter Email" class="form-control" ><br>
                <label for="">Password :</label><br>
                <div class="show-hide">
                    <input type="password" placeholder="Enter Password" id="l_password" class="form-control mb-3 password" name="pass" >
                    <i class="fa-solid fa-eye-slash" id="eye"></i>
                </div><br>
                 <br><br>
                <?php
                    if(isset($error)){
                        //$error = $_SESSION["message"];
                        echo "<div class='alert alert-danger text-center'>$error</div>";
                    }
                ?> 
                <input type="submit" name="submit" value="LOGIN" class="button button-primary">
            </form><br>
 
            <p align="center">Don't Have An Account <a href="signup.php" class="text-primary">Sign up</a></p>
        </div>
        
    </div>
</div>

<script>
    // Show And Hide Password 
    document.getElementById("eye").addEventListener("click", function() {
      const passwordField = document.getElementById("l_password");
      const eyeIcon = document.getElementById("eye");
      
      if (passwordField.type === "password") {
          passwordField.type = "text";
          eyeIcon.classList.remove("fa-eye-slash");
          eyeIcon.classList.add("fa-eye");
      } else {
          passwordField.type = "password";
          eyeIcon.classList.remove("fa-eye");
          eyeIcon.classList.add("fa-eye-slash");
      }
      });
</script>


<?php include 'footer.php'; ?>

