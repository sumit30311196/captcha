<?php

   include 'db.php';
   session_start();
   // Check if the user is logged in
   if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
     // Redirect to the login page
     header('Location: login.php');
     exit;
   }

   $query = "SELECT * FROM `form`";
   $result = $conn->query($query);

?>

<table border="1">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Password</th>
    </tr>
    <?php
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
        
    ?>
    <tr>
        <td><?php echo $row["id"]; ?></td>
        <td><?php echo $row["name"]; ?></td>
        <td><?php echo $row["email"]; ?></td>
        <td><?php echo $row["phone"]; ?></td>
        <td><?php echo $row["password"]; ?></td>
    </tr>
    <?php
        }
        }
    ?>
</table>

    


