<?php
include 'header.php';
include 'db.php';

session_start();
// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  // Redirect to the login page
  header('Location: login.php');
  exit;
}

if (isset($_POST['update'])) {
      // Sanitize input data
      $idd = mysqli_real_escape_string($conn, $_POST['id']);
      $userid = mysqli_real_escape_string($conn, $_POST['userid']);
      $name = mysqli_real_escape_string($conn, $_POST['name']);
      $email = mysqli_real_escape_string($conn, $_POST['email']);
      $phone = mysqli_real_escape_string($conn, $_POST['phone']);

      // Update query
      $updateQuery = "UPDATE `add_crud` SET `id`='$idd',`name`='$name',`email`='$email',`phone`='$phone' WHERE `id`=$idd";
  
      if ($conn->query($updateQuery) === TRUE) {
          header("Location: index1.php?user=$userid");
          
      } else {
          echo "Error updating record: " . $conn->error;
      }
  }
  
  // Close the connection when done
  

$id = $_GET['id'];
$sql = "SELECT * FROM `add_crud` WHERE id = $id";
$result = $conn->query($sql);
while($row = mysqli_fetch_array($result)){
?>


<div class="container">
      <div class="edit_form">
      <h2 class="text-center">User Edit</h2>
            <span></span><br>
      <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
        <div class="row">
          <div class="col-md-12">
            <div class="mb-3">
              <label for="name" class="form-label">Name:</label>
              <input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
              <input type="hidden" class="form-control" name="userid" value="<?php echo $row['userid']; ?>">
              <input type="text" class="form-control" id="email" placeholder="Enter Name" name="name" value="<?php echo $row['name']; ?>">
          </div>
          </div>
          <div class="col-md-12">
            <div class="mb-3">
              <label for="email" class="form-label">Email:</label>
              <input type="email" class="form-control"  placeholder="Enter Email" name="email" value="<?php echo $row['email']; ?>">
            </div>
          </div>
          <div class="col-md-12">
            <div class="mb-3">
              <label for="phone" class="form-label">Phone No:</label>
              <input type="tel" class="form-control" id="ph" placeholder="Enter Phone No." name="phone" value="<?php echo $row['phone']; ?>">
            </div>
          </div>
        </div>

        <button type="submit" name="update" class="btn btn-primary">UPDATE</button>
      </form>
      </div>
      <?php }?>
</div>

<?php include 'footer.php'; ?>