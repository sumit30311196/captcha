<?php

include 'db.php';
session_start();

if (isset($_POST['add_crud'])) {
    $userid = $_POST['userid'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    // $sts = "unblock";

    $sql = "INSERT INTO `add_crud`(`userid`, `name`, `email`, `phone`) VALUES ('$userid','$name','$email','$phone')";
    $qry = $conn->query($sql);

    if ($qry) {
        $_SESSION['success'] = "Registered Successfully";
        header("Location: index1.php?user=$userid&sts=Sucess");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
//exit();

if (isset($_SESSION['msgg'])) {
    $msg = $_SESSION['msgg'];
    unset($_SESSION['msgg']);
}
if (isset($_SESSION["success"])) {
    $success = $_SESSION["success"];
    unset($_SESSION["success"]); // Unset the session variable
}

$conn->close();
