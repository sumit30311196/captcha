<?php
    include 'header.php';
    include 'db.php';
    session_start();

if (isset($_POST['signup'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user = $_POST['user'];
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];

    $duplicate = "SELECT * FROM `form` WHERE `email` = '$email' AND `phone` = '$phone'";
    $dupsql = $conn->query($duplicate);
    $res = mysqli_num_rows($dupsql);

    if($res > 0){
        // echo "<script>
        //         alert('User Already Taken');
        //         window.location.href = 'login.php';
        //     </script>";
        $_SESSION['duplicate']="Email or Phone Number Already Taken";
        header("Location: signup.php");
        exit();
    }else{
        $sql = "INSERT INTO `form`(`name`, `email`, `username`, `phone`, `password`) VALUES ('$name', '$email', '$user', '$phone', '$pass')";
        $qry = $conn->query($sql);

        if ($qry) {
            header("Location: signup.php");
            $_SESSION['success']="Registered Successfully";
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //exit();
}
// if(isset($_SESSION['msgg'])){
//     $msg = $_SESSION['msgg'];
//     unset($_SESSION['msgg']);
// }
if(isset($_SESSION["success"])){
    $success = $_SESSION["success"];
    unset($_SESSION["success"]); // Unset the session variable
}

$conn->close();

?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="bg">
    <div class="login-reg">    
        <div class="sign_up" id="signup">
        <h2 class="text-center">User Sign Up</h2>
            <span></span><br>
        <form onsubmit="return regvalidate()" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="sgg">
                <div class="row">
                    <div class="col-md-6">
                        <label for="">Name :</label><br>
                        <input type="text" name="name" id="r_name" placeholder="Enter Name" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="">Email :</label>
                        <input type="email" name="email" id="r_email" placeholder="Enter Email" class="form-control"><br>
                    </div>
                    <div class="col-md-6">
                        <label for="">Username :</label>
                        <input type="text" name="user" id="r_user" placeholder="Enter Username" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="">Phone :</label><br>
                        <input type="tel" name="phone" id="r_phone" placeholder="Enter Phone" class="form-control">
                    </div>
                    <div class="col-md-12"><br>
                        <label for="">Password :</label><br>
                        <div class="show-hide">
                            <input type="password" placeholder="Enter Password" id="r_pass" class="form-control mb-2" name="pass">
                            <i class="fa-solid fa-eye-slash" id="eye"></i>
                        </div> <br><br><br>
                        <!-- <input type="checkbox" onclick="myshow()"> Show Password  -->
                    </div>
                </div>
                    <?php if(isset($success)) { 
                        //$success = $_SESSION["success"];
                        echo "<div class='alert alert-success text-center'>$success</div>";
                    }if(isset($_SESSION['duplicate'])){
                        echo "<div class='alert alert-warning text-center'>" .$_SESSION['duplicate']. "</div>";
                    }
                    ?> 
                <label for=""class="d-flex">
                    <input type="submit" name="signup" value="SIGNUP" class="button button-primary">
                </label>
            </form><br>
            <p align="center">Already Have An Account <a href="login.php" class="text-primary">Sign in</a></p>
        </div>
    </div>
</div>


<script>
    // Show And Hide Password 
    document.getElementById("eye").addEventListener("click", function() {
      const passwordField = document.getElementById("r_pass");
      const eyeIcon = document.getElementById("eye");
      
      if (passwordField.type === "password") {
          passwordField.type = "text";
          eyeIcon.classList.remove("fa-eye-slash");
          eyeIcon.classList.add("fa-eye");
      } else {
          passwordField.type = "password";
          eyeIcon.classList.remove("fa-eye");
          eyeIcon.classList.add("fa-eye-slash");
      }
      });
</script>



<?php include 'footer.php'; ?>