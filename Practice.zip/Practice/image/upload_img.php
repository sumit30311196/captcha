<?php
include "db.php";

if(isset($_POST['upload'])){
    $filename = $_FILES["uploadfile"]["name"];
    
    $tmp_name = $_FILES["uploadfile"]["tmp_name"];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $newFilename = "newimg_" . uniqid() . "." . $ext;
    $folder = "image/" . $newFilename;  

    //$sql = "INSERT INTO `image` (`filename`) VALUES ('$newFilename')";
    $sql = "UPDATE `image` SET `filename`='$newFilename' WHERE id = 3";

    if($conn->query($sql)){
        if (move_uploaded_file($tmp_name, $folder)) {
            echo "<script>
                    window.location.href = 'index.php';
                    alert('Image Update Successfully');
                 </script>";
        } else {
            echo "<h3>&nbsp; Failed to upload image!</h3>";
        }
    }
}
?>