<?php  
session_start();
// Check if the user is logged in
if (!isset($_SESSION['otp_verify']) || $_SESSION['otp_verify'] !== true) {
  // Redirect to the login page
  header('Location: index.php');
  exit;
}

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

    <title>OTP Login</title>
  </head>
  <body>


    <!---OTP-login---->
    <div class="container my-3">
        <div class="otp text-center">
            <h2 class="text-uppercase">Enter otp</h2>
                <?php
              
                  if(isset($_SESSION['msg'])){
                    ?> 
                      <div class="alert alert-success" role="alert">
                    <?php
                      //unset($_SESSION['error']);
                      echo $_SESSION['msg'];
                    ?>
                      </div>
                    <?php
                  }
                ?>

              <?php
                  //session_start();
                  if(isset($_SESSION['error'])){
                    ?> 
                      <div class="alert alert-danger" role="alert">
                    <?php
                      unset($_SESSION['msg']);
                      echo $_SESSION['error'];
                    ?>
                      </div>
                    <?php
                  }
                ?>
            <form action="login.php" method="POST">
                <input type="text" class="form-control" name="otp" placeholder="Enter 5 Digit OTP" required>
                <button type="submit" name="submit" class="btn btn-success mt-3">VERIFY</button>
            </form>
        </div>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

  </body>
</html>