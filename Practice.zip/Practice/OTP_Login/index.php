<?php 
  // session_start();
  // if (!isset($_SESSION['user'])) {
  //     header('Location: ../index.html');
  //     exit();
  // } 
?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style.css">

    <title>OTP Login</title>
  </head>
  <body>


    <!---OTP-login---->
    <div class="container my-3">
        <div class="otp text-center">
            <h2 class="text-uppercase">OTP Login</h2>
                <?php
                  session_start();
                  if(isset($_SESSION['errorr'])){
                    ?> 
                      <div class="alert alert-danger" role="alert">
                    <?php
                      echo $_SESSION['errorr'];
                    ?>
                      </div>
                    <?php
                  }
                ?>
            <form onsubmit="return validateTheForm()" method="POST" action="send_otp.php">
                <input type="text" class="form-control" name="user_email" placeholder="Enter Email" id="user_email">
                <button type="submit" name="submit" class="btn btn-success mt-3">SEND OTP</button>
            </form>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     <script>
      function validateTheForm() {
        var user_email = document.getElementById("user_email").value;
        if(user_email === ""){
          Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "Enter Email ID"
        });
          return false;
        }
      }
     </script>             


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

  </body>
</html>