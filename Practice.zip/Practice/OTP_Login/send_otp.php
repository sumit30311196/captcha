<?php
session_start();
include "db.php";
include "email.php";

// Check if the user is already logged in, if yes, redirect them to main.php
if (isset($_SESSION['otp_verify']) && $_SESSION['otp_verify'] === true) {
    header('Location: verify.php');
    exit;
}


if (isset($_POST['submit'])) {

    $user_email = $_POST['user_email'];  //variable
    $sql = "SELECT * FROM `users` WHERE user_email='$user_email'"; //quary
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['otp_verify'] = true;
        $_SESSION['email'] = $user_email;
        $otp = rand(11111, 99999);
        //echo "Email Found" .$otp;
        send_otp($user_email, "PHP OTP Login", $otp);
        $sqll = "UPDATE `users` SET `user_otp`='$otp' WHERE `user_email`='$user_email'";
        $resultt = mysqli_query($conn, $sqll) or die(mysqli_error($conn));
        $_SESSION['msg'] = "OTP Send Successfully to Your Registered Email ID";
        header("location:verify.php");
        exit();
        //header("location:verify.php?msg=OTP Send Successfully to Your registered Email ID");
    } else {
        $_SESSION['errorr'] = "Email ID is Invalid Plz Enter Valid Email ID";
        header("location:index.php");
        exit();
        //header("location:index.php?msg=Email ID is Invalid Plz Enter Valid Email ID");
    }
}
