<?php
session_start();
include "db.php";

// Check if the user is already logged in, if yes, redirect them to main.php
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
  header('Location: dashboard.php');
  exit;
}

if (isset($_POST['submit'])) {
  $email = $_SESSION['email'];
  $otp = $_POST['otp'];
  $sql = "SELECT * FROM `users` WHERE `user_email`='$email' AND `user_otp`=$otp";
  $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
  if (mysqli_num_rows($result) > 0) {
    $_SESSION['logged_in'] = true;
    $_SESSION['welcome'] = "Welcome User Login Successfully";
    header("location:dashboard.php");
    exit();
    //header("location:dashboard.php?msg=Welcome User Login Successfully");
  } else {
    $_SESSION['error'] = "Invalid OTP";
    header("location:verify.php");
    exit();
    //header("location:verify.php?msg=Invalid OTP");
  }
}
