<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function send_otp($to, $subject, $content) {
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 0; // Set to 2 for verbose debug output
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'worldbizhubusa@gmail.com'; // Replace with your SMTP username
        $mail->Password = 'ajkjjrofkxqqkunc'; // Replace with your SMTP password
        $mail->SMTPSecure = 'tls'; // or PHPMailer::ENCRYPTION_SMTPS for SSL
        $mail->Port = 587; // Replace with your SMTP port (e.g., 465 for SSL)

        $mail->setFrom('worldbizhubusa@gmail.com', 'OTP for Login'); // Replace with your sender info
        $mail->addAddress($to, "Verify Email"); // Recipient's email address

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = "Your OTP For Login <font color='green'>".$content."</font><br> This OTP is valid for only one Time";
        $mail->AltBody = strip_tags($content);

        $mail->send();
        echo "OTP Has Been Send Successfully";

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        return false; // Indicate failure
    }
}
?>
