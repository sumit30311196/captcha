<?php  
session_start();
// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  // Redirect to the login page
  header('Location: index.php');
  exit;
}

?>



<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <link rel="stylesheet" href="style.css">

  <title>OTP Login</title>
</head>
<body>


  <!---OTP-login---->
  <div class="container my-3">
    <div class="row">
      <div class="col-md-12">
        <div class="text-end">
          <a href="logout.php">Log Out</a>
        </div>
      </div>
    </div>
    <div class="otp">

      <?php
      
      if (isset($_SESSION['welcome'])) {
      ?>
        <div class="alert alert-success" role="alert">
          <?php
          echo $_SESSION['welcome'];
          ?>
        </div>
      <?php
      }
      ?>

    </div>
  </div>


  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

  <!-- jQuery library -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

</body>
</html>